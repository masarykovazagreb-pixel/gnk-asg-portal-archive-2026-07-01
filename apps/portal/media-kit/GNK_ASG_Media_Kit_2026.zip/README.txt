GNK DINAMO Ltd. Group / GNK ASG d.o.o. — Media Kit
====================================================

Sadržaj:
- /logos/          Službeni gold transparent i gold dark logotipi (obje tvrtke, PNG)
- /reports/        Financijska izvješća FY2025 (revidirano GNK ASG, management-certified Grupa)
- /factsheet/      Jednostranični korporativni fact sheet (PDF)

Korištenje logotipa: bez rastezanja, deformacije ili postavljanja unutar dekorativnih oblika.
Kontakt za medije: media@gnk-asg.hr
Web: https://www.gnk-asg.hr

THE CODE — službeno predstavljanje 7. listopada 2026. u 11:30 ET, New York.
