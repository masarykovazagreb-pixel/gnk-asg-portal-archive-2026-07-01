# GNK ASG — mobilna aplikacija (PWA)
## Uputa za postavljanje na server

Verzija: 1.0 · Kontakt za sadržaj: GNK ASG d.o.o., Zagreb

---

## 1. Što je u ovom paketu

```
app/                          ← OVO se postavlja na server (statične datoteke, radi na Cloudflareu)
  index.html                  aplikacija (jedna datoteka)
  support.js                  runtime aplikacije
  manifest.webmanifest        identitet aplikacije (ime, ikone, id: /app/)
  sw.js                       service worker — offline rad i obavijesti
  map.html                    karta grupne mreže (OpenStreetMap + Leaflet)
  icons/                      ikone 192, 512, maskable, apple-touch
  _ds/                        stilovi (dizajn sustav)

server/                       ← OPCIONALNO, nije nužno za rad aplikacije
  README-cloudflare.md        ★ protokol koji Worker mora ispuniti (za opciju B)
  objave-api.php              /api/objave    ┐
  messages-api.php            /api/messages  │ samo za zaseban PHP hosting (opcija A)
  ai-api.php                  /api/ai        │ — na gnk-asg.hr PHP se NE izvršava
  linkedin-relay.php|.js      /api/linkedin  ┘
  UPUTA-*.md                  upute za svaki endpoint
```

---

## 2. Postavljanje aplikacije (5 minuta, bez programiranja)

1. Prekopirajte **cijelu mapu `app/`** na web server (FTP ili cPanel → File Manager),
   u korijen stranice, tako da se otvara na adresi:

   ```
   https://gnk-asg.hr/app/
   ```

2. Ništa se u datotekama ne mijenja. Struktura mora ostati ista
   (`sw.js`, `manifest.webmanifest` i `icons/` u istoj mapi kao `index.html`).

3. Provjera: otvorite `https://gnk-asg.hr/app/` — mora se prikazati aplikacija.

**Uvjeti servera**
- HTTPS (postoji)
- `.webmanifest` mora se posluživati kao `application/manifest+json`

  Cloudflare Pages / statične datoteke — datoteka `_headers` u korijenu:

  ```
  /app/manifest.webmanifest
    Content-Type: application/manifest+json
  /app/sw.js
    Cache-Control: no-cache
  ```

  Apache (`.htaccess`):

  ```apache
  AddType application/manifest+json .webmanifest
  <FilesMatch "sw\.js$">
    Header set Cache-Control "no-cache"
  </FilesMatch>
  ```

- Nginx:

  ```nginx
  types { application/manifest+json webmanifest; }
  location = /app/sw.js { add_header Cache-Control "no-cache"; }
  ```

---

## 3. Instalacija na mobitel

**Android (Chrome)**
`https://gnk-asg.hr/app/` → meni ⋮ → **Instaliraj aplikaciju** → ikona GNK ASG na ekranu.
Aplikacija se otvara bez adresne trake i radi offline (zadnji viđeni podatci).

**iPhone (Safari)** — Podijeli → *Dodaj na početni ekran*.

**Dvije zasebne ikone.** Aplikacija ima vlastiti manifest (`id: "/app/"`), pa je Chrome
tretira odvojeno od portala — mogu se instalirati i portal i aplikacija.

**QR kod.** U aplikaciji: Više → *QR kod za instalaciju* → „Preuzmi QR".
Sliku stavite na web stranicu / posjetnicu; skeniranje otvara aplikaciju i nudi instalaciju.

**Gumb na web stranici** (za programera):

```html
<a href="/app/" class="btn btn-primary">Instaliraj GNK ASG aplikaciju</a>
```

---

## 4. Što aplikacija radi bez ikakvog servera

Radi u cijelosti — svi ekrani, offline pristup, sve što je lokalno:

Naslovnica s pokazateljima FY 2025 · Puls tržišta (kripto uživo, CoinGecko) ·
Trgovanje uživo (osvježavanje 30 s) · Svjetska tržišta (Stooq) · grafovi po simbolu ·
cjenovni alarmi i obavijesti · AKTUAL MEDIA vijesti (RSS) · Objave, Analize (čita s portala) ·
Grupna mreža s kartom · Financije i graf prihoda · Dokumenti · Projekti · THE CODE ·
Recepti · Trgovina · Restorani · Ideje · AI asistent (offline baza znanja) · Pretraživanje ·
Notifikacije · Kalendar · Statistika · Zaposlenici · Dokumenti za potpis · Poruke tima ·
Putni troškovi · Fotogalerija · Ugovori · Sastanci · HR/EN · tamna i svijetla tema ·
diktiranje glasom · dijeljenje i LinkedIn.

Objave napravljene u aplikaciji bez servera ostaju spremljene lokalno i označene
„čeka sinkronizaciju" — ništa se ne gubi.

---

## 5. Za programera — poslužiteljski dio (VAŽNO: portal je na Cloudflareu)

Portal `gnk-asg.hr` radi na **Cloudflare Workerima i statičkim datotekama — PHP se ne izvršava.**
PHP datoteke u mapi `server/` upotrebljive su samo na zasebnom običnom hostingu (opcija A).

**Opcija B (preporučeno)** — worker `gnk-asg-app-api` s istim rutama:

```
npx wrangler secret put GNK_TOKEN_SECRET --name gnk-asg-app-api
npx wrangler secret put GNK_ADMIN_USER   --name gnk-asg-app-api
npx wrangler secret put GNK_ADMIN_HASH   --name gnk-asg-app-api   # SHA-256 lozinke, hex
npx wrangler deploy
```

`GNK_ADMIN_HASH`: `echo -n "lozinka" | sha256sum` (nije bcrypt).
Provjera: `https://gnk-asg.hr/api/app-health` → `{ "ok": true }`

Rute u Cloudflare nadzornoj ploči moraju pokazivati na taj worker i ne preklapati se s glavnim:
`/api/objave*`, `/api/messages*`, `/api/ai`, `/api/linkedin`, `/api/stats`, `/api/app-health`.

**Točan protokol koji aplikacija očekuje (zahtjevi i odgovori, polje po polju) je u
`server/README-cloudflare.md`.** Ako se worker toga drži, u aplikaciji se ne mijenja ništa —
samo se upišu adrese.

| Endpoint | Čemu služi |
| --- | --- |
| `POST /api/objave/login` | prijava istim admin podatcima kao stranica |
| `POST /api/objave` | objava (naslov, tekst, fotografija) |
| `GET /api/objave` | popis objava koji aplikacija prikazuje |
| `GET/POST /api/messages` | zajednička nit „Poruke tima" |
| `POST /api/linkedin` | objava na LinkedIn (token ostaje na serveru) |
| `POST /api/ai` | AI asistent na javnim podatcima portala |
| `GET /api/stats` | posjeti portalu za ekran Statistika |

Adrese se upisuju **u samoj aplikaciji**, ne u kodu:
- Objavi → *Server za objavu*: `https://gnk-asg.hr/api/objave`
- Više → *LinkedIn*: adresa relaya + pristupni ključ (`GNK_APP_KEY`)
- AI asistent → *Poveži s portalom*: `https://gnk-asg.hr/api/ai`
- Poruke tima → *Server tima*: `https://gnk-asg.hr/api/messages`
- Statistika → *Posjeti portalu*: `https://gnk-asg.hr/api/stats`

Varijable okoline / secrets (nikad u aplikaciji):
`GNK_ADMIN_USER`, `GNK_ADMIN_HASH`, `GNK_TOKEN_SECRET`, `GNK_APP_KEY`,
`LINKEDIN_TOKEN`, `LINKEDIN_AUTHOR`, `AI_KEY`.

**Logo:** koristiti `logo-gnk-asg.svg` ili `logo-gnk-asg-gold.svg`.
`logo-gnk-asg-canonical.svg` je neispravan i ne prikazuje se — ikone u `app/icons/`
napravljene su neovisno o njemu i rade; ako želite ikone iz pravog logotipa, pošaljite SVG.


---

## 6. Ažuriranje aplikacije kasnije

Prekopira se nova mapa `app/` preko stare. Korisnici dobiju novu verziju pri sljedećem
otvaranju (service worker osvježava predmemoriju). Ako se ne osvježi odmah:
u Chromeu ⋮ → *Osvježi*.

---

## 7. Google Play (ako se poželi APK)

Ista adresa `https://gnk-asg.hr/app/` pakira se alatom **PWABuilder**
(Trusted Web Activity) u APK/AAB — bez ponovne izrade aplikacije.
Potrebno: Google Play Developer račun i `assetlinks.json` na domeni
(`/.well-known/assetlinks.json`), koji PWABuilder generira.

---

## 8. Privatnost

Sve što korisnik unese u aplikaciji (objave prije sinkronizacije, imenik zaposlenika,
putni troškovi, fotografije, potpisi, ugovori, sastanci, bilješke, statistika korištenja)
ostaje **na uređaju** (localStorage). Van uređaja ide samo ono što korisnik izričito
pošalje na portal ili LinkedIn. Tržišni podatci dohvaćaju se iz javnih izvora
(CoinGecko, Frankfurter/ECB, Stooq, javni RSS) i informativni su.

---

## 9. Kontrolna lista prije objave

- [ ] mapa `app/` na `https://gnk-asg.hr/app/`, otvara se ispravno
- [ ] `.webmanifest` MIME tip postavljen (Cloudflare: `_headers` ili Worker odgovor)
- [ ] Chrome na Androidu nudi „Instaliraj aplikaciju"
- [ ] ikona na ekranu telefona otvara aplikaciju bez adresne trake
- [ ] u zrakoplovnom načinu aplikacija se otvara (offline)
- [ ] gumb / QR kod za instalaciju postavljen na web stranicu
- [ ] provjereni telefon i e-mail u „Brzi kontakt" (trenutno `091 535 8365`, `info@gnk-asg.hr`)
- [ ] (opcionalno) worker `gnk-asg-app-api` objavljen, `/api/app-health` vraća `{ok:true}`,
      adrese upisane u aplikaciji
