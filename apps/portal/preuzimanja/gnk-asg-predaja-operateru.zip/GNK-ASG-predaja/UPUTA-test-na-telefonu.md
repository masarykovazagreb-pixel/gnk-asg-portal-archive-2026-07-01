# Test na telefonu — 10 minuta

Ovaj paket je za **isprobavanje aplikacije na mobitelu**, prije objave na portal.

---

## A) Najbrži put — bez servera (2 minute)

1. Prekopirajte mapu `app/` bilo gdje na neku **HTTPS** adresu, npr.:
   - `gnk-asg.hr/app-test/` (privremeno, može biti zaštićeno ili s `noindex`)
   - ili bilo koji besplatni statični hosting
2. Na telefonu u Chromeu otvorite tu adresu.
3. Meni ⋮ → **Instaliraj aplikaciju**.

Bez HTTPS-a instalacija i otisak prsta ne rade (to je pravilo preglednika, ne aplikacije).
Za brzi pogled bez instalacije adresa radi i kao običan web.

---

## B) Test bez ikakvog hostinga

Na računalu, u mapi `app/`:

```
python3 -m http.server 8000
```

Zatim na telefonu (isti Wi-Fi): `http://<IP-računala>:8000/`
Radi za pregled i klikanje; **instalacija i otisak prsta neće raditi** (nije HTTPS).

---

## Što provjeriti na telefonu (kontrolna lista)

**Instalacija**
- [ ] Chrome nudi „Instaliraj aplikaciju"
- [ ] ikona GNK ASG je na ekranu i otvara se **bez adresne trake**
- [ ] u zrakoplovnom načinu aplikacija se otvara i prikazuje zadnje podatke

**Podatci uživo**
- [ ] Tržišta: kripto cijene se učitaju (CoinGecko)
- [ ] Tržišta → Indeksi: S&P, DAX, CROBEX, zlato, nafta
- [ ] Vijesti: naslovi sa slikama, otvaraju izvor
- [ ] Grupna mreža: karta se prikaže i može se povlačiti

**Zaštita**
- [ ] Više → Postavke → PIN: postavite 4–8 brojeva
- [ ] otvaranje Ugovora traži PIN; pogrešan PIN ne pušta dalje
- [ ] „Otisak prsta / lice" → Uključi → telefon zatraži otisak
- [ ] nakon 2 min neaktivnosti privatni ekran se sam zaključa

**Rad na terenu**
- [ ] Objavi: uslikaj → izdiktiraj kontekst (◉) → „Napiši tekst" → sprema se lokalno
- [ ] Sastanci: „Diktiraj sastanak" — recite „sastanak u petak u 14 i 30 u Zagrebu s Markom"
      → sastanak dodan i .ics otvara kalendar
- [ ] Putni troškovi: uslikaj račun, dodaj iznos, „Izvezi CSV"
- [ ] Dokumenti za potpis: potpis prstom → „Preuzmi"
- [ ] Fotogalerija: više slika odjednom, „U objavu"

**Obavijesti**
- [ ] Postavke → obavijesti o objavama / vijestima / tržištima → Uključi (dozvola)
- [ ] dođe potvrdna obavijest

**Widget i QR**
- [ ] dugi pritisak na ikonu → prečac „Tržišta (widget)"
- [ ] Više → QR kod → skeniranje drugim telefonom otvara aplikaciju

---

## Ako nešto ne radi

| Simptom | Uzrok | Rješenje |
| --- | --- | --- |
| nema „Instaliraj aplikaciju" | nije HTTPS ili manifest se ne poslužuje kao `application/manifest+json` | vidi `UPUTA-instalacija.md`, dio 2 |
| bijeli ekran | `support.js` nije prekopiran uz `index.html` | prekopirajte cijelu mapu `app/` |
| karta prazna | nema interneta pri prvom otvaranju | otvorite Grupnu mrežu jednom online |
| otisak prsta ne nudi | `http://` adresa ili uređaj bez biometrije | koristite HTTPS |
| tržišta prazna | javni izvor privremeno odbija zahtjev | pritisnite „Osvježi" ili pričekajte minutu |
| objave se ne šalju na portal | endpoint nije postavljen | radi lokalno; vidi `server/README-cloudflare.md` |

---

## Nakon testa

Kad potvrdite da radi, ista mapa `app/` ide na konačnu adresu
`https://gnk-asg.hr/app/` — bez izmjena u datotekama
(`UPUTA-instalacija.md`, dio 2). Testnu adresu tada ugasite da ne postoje dvije verzije.

Sve što unesete u testu (PIN, objave, troškovi, potpisi) ostaje na tom telefonu i
ne prelazi na konačnu instalaciju ako je adresa druga — očekujte prazan početak.
