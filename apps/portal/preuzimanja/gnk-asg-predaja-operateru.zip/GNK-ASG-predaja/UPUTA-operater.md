# GNK ASG — mobilna aplikacija
## Upute za operatera / administratora portala

Verzija 1.0 · Predaja: srpanj 2026. · Naručitelj: GNK ASG d.o.o., Zagreb

---

## 0. Što se predaje i tko što radi

| Dio | Datoteke | Kome |
| --- | --- | --- |
| Aplikacija (statične datoteke) | `app/` | operater — samo prekopirati na server |
| Uputa za instalaciju | `UPUTA-instalacija.md` | operater |
| Uputa za test na telefonu | `UPUTA-test-na-telefonu.md` | operater + naručitelj |
| API ugovor za Cloudflare Worker | `server/README-cloudflare.md` | programer (opcionalno) |
| PHP izvedba istih API-ja | `server/*.php`, `UPUTA-*.md` | programer, samo za obični hosting |

**Aplikacija radi bez ijednog poslužiteljskog dijela.** Poslužiteljski dio služi samo
da objave iz aplikacije idu na portal i LinkedIn, te za zajedničku nit poruka.

---

## 1. Instalacija na server — 3 koraka

### 1.1 Prekopirati mapu

Cijela mapa `app/` ide na server tako da se otvara na:

```
https://gnk-asg.hr/app/
```

Struktura se **ne mijenja** — `index.html`, `support.js`, `manifest.webmanifest`,
`sw.js`, `map.html`, `icons/`, `assets/`, `_ds/` moraju ostati u istoj mapi
(`sw.js` i `manifest.webmanifest` obavezno uz `index.html`, inače instalacija ne radi).

### 1.2 Postaviti dva zaglavlja

Portal je na Cloudflareu (statične datoteke + Workeri), pa `_headers` u korijenu:

```
/app/manifest.webmanifest
  Content-Type: application/manifest+json
/app/sw.js
  Cache-Control: no-cache
```

Apache (`.htaccess`) ekvivalent:

```apache
AddType application/manifest+json .webmanifest
<FilesMatch "sw\.js$">
  Header set Cache-Control "no-cache"
</FilesMatch>
```

Bez prvog zaglavlja Chrome ne nudi „Instaliraj aplikaciju"; bez drugog korisnici
ostaju na staroj verziji nakon ažuriranja.

### 1.3 Provjeriti

1. `https://gnk-asg.hr/app/` — aplikacija se prikaže.
2. Android Chrome → ⋮ → **Instaliraj aplikaciju** → ikona na ekranu.
3. Zrakoplovni način → aplikacija se otvara (offline rad).

**HTTPS je obavezan.** Preko `http://` aplikacija se vidi, ali se ne može instalirati i
otisak prsta ne radi.

---

## 2. Ugradnja na web stranicu

Gumb (bilo gdje u navigaciji ili podnožju):

```html
<a href="/app/" class="btn btn-primary">Instaliraj GNK ASG aplikaciju</a>
```

QR kod: u aplikaciji Više → **QR kod za instalaciju** → „Preuzmi QR", ili tiskani plakat
(A4) koji je predan zasebno. Skeniranje otvara `/app/` i Chrome nudi instalaciju.

**Portal i aplikacija su dvije ikone.** Aplikacija ima vlastiti manifest (`id: "/app/"`),
pa se instalira neovisno od portala i ne dira postojeću instalaciju stranice.

---

## 3. Ažuriranje

Nova mapa `app/` prekopira se preko stare. Korisnici dobiju novu verziju pri sljedećem
otvaranju (service worker osvježava predmemoriju u pozadini). Ako treba odmah:
u aplikaciji ⋮ → Osvježi.

Ne mijenjajte `index.html` ručno — sadržaj i ekrani generiraju se iz izvora; ručna izmjena
bila bi izgubljena pri prvom ažuriranju.

---

## 4. Opcionalni poslužiteljski dio

Portal ne izvršava PHP (Cloudflare Workeri), pa su dva puta:

**A — Cloudflare Worker (preporučeno).** Programer objavljuje worker s rutama
`/api/objave/login`, `/api/objave`, `/api/messages`, `/api/ai`, `/api/linkedin`,
`/api/stats`, `/api/app-health`. Točan protokol (zahtjev/odgovor, polje po polju) je u
`server/README-cloudflare.md`. Tajne se postavljaju kao Worker secrets:

```
GNK_TOKEN_SECRET   potpisivanje tokena (HMAC)
GNK_ADMIN_USER     admin korisnik
GNK_ADMIN_HASH     SHA-256 lozinke u hex zapisu (nije bcrypt)
GNK_APP_KEY        ključ za LinkedIn relay
LINKEDIN_TOKEN     LinkedIn pristupni token
LINKEDIN_AUTHOR    urn:li:person:... ili organization
AI_KEY             ključ AI servisa
```

Provjera nakon objave: `https://gnk-asg.hr/api/app-health` → `{"ok":true}`.
Rute moraju biti dodijeljene tom workeru i ne preklapati se s glavnim workerom portala.

**B — zaseban obični hosting s PHP-om.** Datoteke `objave-api.php`, `messages-api.php`,
`ai-api.php`, `linkedin-relay.php` postave se tamo, iste varijable okoline, a u aplikaciji
se upiše ta adresa.

Adrese se **upisuju u aplikaciji**, ne u kodu:

| Ekran u aplikaciji | Polje | Vrijednost |
| --- | --- | --- |
| Objavi | Server za objavu | `https://gnk-asg.hr/api/objave` |
| Više → LinkedIn | relay + ključ | `https://gnk-asg.hr/api/linkedin` + `GNK_APP_KEY` |
| AI asistent | Poveži s portalom | `https://gnk-asg.hr/api/ai` |
| Poruke tima | Server tima | `https://gnk-asg.hr/api/messages` |
| Statistika | Posjeti portalu | `https://gnk-asg.hr/api/stats` |

---

## 5. Sigurnost — što je gdje

**Prema serveru.** Prijava ide na `POST /api/objave/login`; token je HMAC-SHA256 s rokom
30 dana i šalje se kao `Authorization: Bearer` na svaku objavu, sinkronizaciju, poruku i
LinkedIn objavu. Server odbija `POST`/`DELETE` bez valjanog tokena (401).
LinkedIn i AI ključevi **nikad ne ulaze u aplikaciju** — ostaju na serveru.

**Na uređaju.** Privatni ekrani (Ugovori, Putni troškovi, Zaposlenici, Dokumenti za potpis,
Poruke tima, Fotogalerija, Sastanci, Objavi) zaštićeni su **PIN-om** (4–8 brojeva, čuva se
samo kao SHA-256 sažetak) i po želji **otiskom prsta / licem** (WebAuthn — biometrija ne
napušta telefon). Auto-zaključavanje nakon 2 minute neaktivnosti i pri svakom otvaranju.
Postavke → **Obriši lokalne podatke** briše sve s uređaja u slučaju gubitka telefona.

**Privatnost.** Objave prije sinkronizacije, imenik, troškovi, fotografije, potpisi,
ugovori, sastanci, bilješke i statistika korištenja ostaju u `localStorage` na uređaju.
Van uređaja ide samo ono što korisnik izričito pošalje. Tržišni podatci dolaze iz javnih
izvora (CoinGecko, Frankfurter/ECB, Stooq, javni RSS) i informativni su.

PIN se postavlja **u aplikaciji na telefonu**, nije vezan na web prijavu i ne postavlja se
sa servera.

---

## 6. Google Play (ako se poželi APK)

Adresa `https://gnk-asg.hr/app/` pakira se alatom **PWABuilder** (Trusted Web Activity) u
APK/AAB — bez ponovne izrade aplikacije. Potrebno: Google Play Developer račun i
`/.well-known/assetlinks.json` na domeni (generira ga PWABuilder).

---

## 7. Sadržaj aplikacije (za korisničku uputu)

Početna s pokazateljima FY 2025 · Puls tržišta (kripto uživo) · Trgovanje uživo ·
Svjetska tržišta (indeksi i roba) · grafovi po simbolu · cjenovni alarmi ·
AKTUAL MEDIA vijesti · Objave · Analize · Grupna mreža s kartom · Financije ·
Dokumenti · Projekti · THE CODE odbrojavanje · Recepti · Trgovina · Restorani · Ideje ·
AI asistent · Pretraživanje · Notifikacije · Kalendar · Statistika · Zaposlenici ·
Dokumenti za potpis · Poruke tima · Putni troškovi · Fotogalerija · Ugovori ·
Sastanci (uz glasovno zakazivanje) · HR/EN · tamna i svijetla tema · diktiranje ·
dijeljenje i LinkedIn · widget prikaz · QR kod za instalaciju.

---

## 8. Kontrolna lista predaje

- [ ] mapa `app/` na `https://gnk-asg.hr/app/`
- [ ] `_headers` (ili `.htaccess`) postavljen
- [ ] Chrome na Androidu nudi „Instaliraj aplikaciju"
- [ ] offline provjera prošla
- [ ] gumb i/ili QR kod na web stranici
- [ ] provjereni kontakt podatci u aplikaciji (telefon, e-mail)
- [ ] PIN postavljen na uređajima koji drže privatne podatke
- [ ] (opcionalno) worker objavljen, `/api/app-health` vraća `{"ok":true}`, adrese upisane
- [ ] testna adresa ugašena nakon puštanja u rad

Pitanja o poslužiteljskom dijelu: `server/README-cloudflare.md`.
Pitanja o instalaciji: `UPUTA-instalacija.md`. Test na telefonu: `UPUTA-test-na-telefonu.md`.
