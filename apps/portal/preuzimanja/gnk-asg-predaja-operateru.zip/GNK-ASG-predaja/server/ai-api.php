<?php
/**
 * GNK ASG — AI asistent (relay za aplikaciju)
 * Postaviti kao: https://www.gnk-asg.hr/api/ai  (npr. /api/ai/index.php)
 *
 * Aplikacija šalje:  POST { "question": "…", "lang": "hr"|"en", "source": "app" }
 * Vraća:             { "ok": true, "answer": "…" }
 *
 * Asistent odgovara SAMO iz javnih podataka portala (kontekst niže) — bez izmišljanja.
 * Ako AI servis nije dostupan, vraća 503 i aplikacija odgovara iz vlastitih podataka.
 */

declare(strict_types=1);

$ALLOW_ORIGIN = 'https://www.gnk-asg.hr';
$AI_URL   = getenv('AI_URL')   ?: 'https://api.anthropic.com/v1/messages';
$AI_KEY   = getenv('AI_KEY')   ?: '';                 // API ključ ostaje na serveru
$AI_MODEL = getenv('AI_MODEL') ?: 'claude-sonnet-4-5';
$RATE_DIR = sys_get_temp_dir() . '/gnk-ai-rate';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . $ALLOW_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Vary: Origin');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { out(405, ['ok' => false, 'error' => 'Only POST']); }

/* Ograničenje: 20 pitanja na 10 minuta po IP-u (asistent je javan). */
@mkdir($RATE_DIR, 0775, true);
$ipFile = $RATE_DIR . '/' . md5((string)($_SERVER['REMOTE_ADDR'] ?? '')) . '.txt';
$hits = array_values(array_filter(
    array_map('intval', explode(',', (string)@file_get_contents($ipFile))),
    fn($t) => $t > time() - 600
));
if (count($hits) >= 20) { out(429, ['ok' => false, 'error' => 'Previše pitanja. Pokušajte za nekoliko minuta.']); }
$hits[] = time();
@file_put_contents($ipFile, implode(',', $hits));

$in  = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];
$q   = trim((string)($in['question'] ?? ''));
$lang = ($in['lang'] ?? 'hr') === 'en' ? 'en' : 'hr';
if ($q === '' || mb_strlen($q) > 500) { out(422, ['ok' => false, 'error' => 'Neispravno pitanje.']); }
if ($AI_KEY === '') { out(503, ['ok' => false, 'error' => 'AI servis nije konfiguriran.']); }

/* ─── Kontekst: javni podatci portala ──────────────────────────────────── */

$CONTEXT = <<<TXT
GNK ASG d.o.o. — Zagrebačka cesta 130, Zagreb, Hrvatska. OIB 75227917632, MBS 081512375.
Osnovano 12. svibnja 2023. Pretežita djelatnost: sportske djelatnosti, NKD 93.19.0.
Direktor i stvarni vlasnik (UBO): Nermin Sefić. Član društva: Sports Performance Tracking d.o.o., Beograd.

FY 2025 (revidirano, EKVILIBRIJ d.o.o.):
- ukupni prihodi 504,00 mil. EUR
- ukupna aktiva 46,40 mil. EUR (31.12.2025.)
- kapital i rezerve 46,21 mil. EUR (99,60 % aktive)
- kratkoročne obveze 184,50 tis. EUR; dugoročne obveze 0,00 EUR
- dobit prije oporezivanja 21.584,16 EUR; dobit godine 16.076,47 EUR
- nematerijalna imovina / softver 30.000.000,00 EUR

Grupa GNK DINAMO Ltd. (Boulder, Colorado, USA; Entity ID 20238180649; 33 povezana društva, 12 lokacija;
ovlašteni predstavnik i UBO: Nermin Sefić). Konsolidirano FY 2025: prihodi 4,7046 mlrd. EUR,
neto dobit 982,48 mil. EUR, aktiva 3,4830 mlrd. EUR, kapital 3,4140 mlrd. EUR, obveze 69,04 mil. EUR,
udio kapitala 98,02 %. Grupni podatci su management-certified i internally group-reviewed za Colorado
public disclosure filing — nisu neovisno revidirani izvještaji GNK ASG d.o.o.

Sadržaj portala: Puls tržišta (kripto, valute, 22 indeksa, 25 sirovina — javni izvori CoinGecko, Yahoo
Finance, ECB), AKTUAL MEDIA (vijesti iz javnih RSS izvora, ažuriranje svaka 2 sata), Objave (30+
autorskih članaka), Analize, Komentari, Grupna mreža, Projekti (zdravstvo, sport, Bitcoin Payment
Processor, Digital Exchange, zlatom povezan digitalni instrument, sveučilište, hrana, industrija,
energetska trgovina, THE CODE), THE CODE (aktivacija 7. listopada 2026., 11:30 ET, New York),
The World Table (789 recepata, 14 kategorija), Trgovina, GNK Royal restorani (Hong Kong, Kairo,
Singapur), Ideje u djelovanju, SYNAPSE AI 3D demo.

Tržišni podatci su informativni. Portal ne pruža kupnju, prodaju ni čuvanje digitalne imovine,
ni investicijsko savjetovanje.
TXT;

$rules = $lang === 'en'
    ? "Answer in English, briefly (max 4 sentences), only from the context. If the answer is not in the context, say so and point to www.gnk-asg.hr. Never give investment advice or invent figures."
    : "Odgovaraj na hrvatskom, kratko (najviše 4 rečenice), isključivo iz konteksta. Ako odgovora nema u kontekstu, reci to i uputi na www.gnk-asg.hr. Nikad ne daj investicijski savjet ni izmišljen podatak.";

/* ─── Poziv AI servisa (Anthropic Messages API) ────────────────────────── */

$payload = [
    'model'      => $AI_MODEL,
    'max_tokens' => 500,
    'system'     => $rules . "\n\nKONTEKST (javni podatci portala):\n" . $CONTEXT,
    'messages'   => [['role' => 'user', 'content' => $q]],
];

$ch = curl_init($AI_URL);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 45,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . $AI_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);
$res  = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$j = json_decode((string)$res, true);
$answer = '';
if (is_array($j) && !empty($j['content'])) {
    foreach ($j['content'] as $blk) { if (($blk['type'] ?? '') === 'text') { $answer .= $blk['text']; } }
}
$answer = trim($answer);

if ($code < 200 || $code >= 300 || $answer === '') {
    out(503, ['ok' => false, 'error' => 'AI servis nije odgovorio.']);
}

out(200, ['ok' => true, 'answer' => $answer]);

function out(int $code, array $data): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
