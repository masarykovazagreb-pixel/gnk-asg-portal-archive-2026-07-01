# /api/objave — postavljanje

Datoteka: `objave-api.php` → postavite kao `https://www.gnk-asg.hr/api/objave/index.php`
(Apache prepisuje `/api/objave` na `index.php`; ako koristite Nginx, uputite lokaciju na PHP-FPM.)

## 1. Administrator (isti podatci kao na web stranici)
Napravite hash lozinke:

    php -r 'echo password_hash("vasa-lozinka", PASSWORD_DEFAULT), "\n";'

i postavite varijable okoline (ili vrijednosti na početku datoteke):

    GNK_ADMIN_USER    = admin
    GNK_ADMIN_HASH    = $2y$10$…            (hash iz gornje naredbe)
    GNK_TOKEN_SECRET  = dugačak slučajan niz

Ako portal već ima svoju bazu korisnika, u dijelu `1. Prijava` zamijenite provjeru pozivom na
postojeću funkciju prijave — ostatak ostaje isti.

## 2. Mape i prava pisanja
- `_data/` — JSON zapisi objava (najbolje van web korijena)
- `/assets/objave/` — slike iz aplikacije
- `/objave/<slug>/`, `/komentari/<slug>/` — generirane stranice (`$WRITE_PAGES = true`)

Ako objave prikazujete kroz vlastiti CMS ili predložak, stavite `$WRITE_PAGES = false` i čitajte `_data/`.

## 3. Aplikacija
Objavi → *Server za objavu*: `https://www.gnk-asg.hr/api/objave`
Prijava tada ide na `/api/objave/login`, objava na `/api/objave`, a lista objava učitava se s portala.

## Protokol

    POST /api/objave/login
    { "user": "admin", "password": "…" }              → { ok: true, token: "…" }

    POST /api/objave                                   Authorization: Bearer <token>
    { "category": "objave"|"komentari", "title": "…", "body": "…", "image": "data:image/jpeg;base64,…" }
                                                       → { ok: true, id, url, image }

    GET  /api/objave?limit=40&category=objave          → { ok: true, items: [ … ] }   (javno)
    DELETE /api/objave?id=<id>                         Authorization: Bearer <token> → { ok: true }

Token je HMAC-potpisan i vrijedi 30 dana. Slike su ograničene na 8 MB; aplikacija ih smanjuje na 1280 px.
