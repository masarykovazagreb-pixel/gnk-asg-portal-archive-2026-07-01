# /api/messages — poruke tima

Datoteka: `messages-api.php` → postaviti kao `https://www.gnk-asg.hr/api/messages/index.php`

## 1. Postavljanje
1. Kopirati datoteku i napraviti mapu `_data/` s pravom pisanja (`755`/`775`).
2. `GNK_TOKEN_SECRET` mora biti **isti** kao u `objave-api.php` — tada aplikacija koristi
   isti token dobiven prijavom na `/api/objave/login`, bez druge prijave.
3. U aplikaciji: Više → Poruke tima → *Server tima* = `https://www.gnk-asg.hr/api/messages`

Poruke se čuvaju u `_data/messages.jsonl` (zadnjih 500), bez baze podataka.

## 2. Protokol

    GET  /api/messages?limit=100          Authorization: Bearer <token>
      → { ok: true, items: [ { id, author, text, at } ], now: <ms> }

    GET  /api/messages?since=<ms>         (samo novije od zadanog vremena — za brzo osvježavanje)

    POST /api/messages                    Authorization: Bearer <token>
      { "author": "Nermin", "text": "..." }
      → { ok: true, item: { id, author, text, at } }

    DELETE /api/messages?id=<id>          Authorization: Bearer <token>
      → { ok: true }

Aplikacija osvježava nit svakih 15 sekundi dok je ekran otvoren; bez servera poruke
ostaju lokalne bilješke.

## 3. Sigurnost i privatnost
- Pisanje i brisanje traže valjan token (HMAC potpisan, rok 30 dana).
- Čitanje također traži token; za javni kanal postaviti `$READ_PUBLIC = true`.
- Sprema se samo **hash** IP adrese, radi zaštite od zloupotrebe.
- Ista poruka istog autora u 10 sekundi ne duplicira se.
- Poruka je ograničena na 2000 znakova.

## 4. Ako želite web prikaz niti na portalu
`readAll()` vraća polje zapisa — dovoljno je proći kroz `_data/messages.jsonl`
u vašem predlošku i ispisati `author`, `text` i `at`.
