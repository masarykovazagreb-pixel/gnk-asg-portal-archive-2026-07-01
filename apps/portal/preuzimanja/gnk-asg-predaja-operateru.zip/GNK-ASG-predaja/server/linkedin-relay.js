/**
 * GNK ASG — LinkedIn relay (Node 18+, Express)
 * Ruta: POST /api/linkedin   → koristi je aplikacija (Više → LinkedIn → adresa relaya)
 *
 * Pokretanje:
 *   npm i express
 *   GNK_APP_KEY=... LINKEDIN_TOKEN=... LINKEDIN_AUTHOR=urn:li:person:XXX node linkedin-relay.js
 *
 * Aplikacija šalje: { author, text, url, image }  + Authorization: Bearer <GNK_APP_KEY>
 * LinkedIn token nikad ne izlazi iz servera.
 */

const express = require('express');

const APP_KEY = process.env.GNK_APP_KEY || 'promijeni-me-dugacki-slucajni-niz';
const LI_TOKEN = process.env.LINKEDIN_TOKEN || '';
const LI_AUTHOR = process.env.LINKEDIN_AUTHOR || '';
const ORIGIN = process.env.ALLOW_ORIGIN || 'https://www.gnk-asg.hr';
const LI_VERSION = '202405';
const PORT = process.env.PORT || 8787;

const app = express();
app.use(express.json({ limit: '12mb' }));

app.use('/api/linkedin', (req, res, next) => {
  res.set({
    'Access-Control-Allow-Origin': ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    Vary: 'Origin'
  });
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  const m = /^Bearer\s+(.+)$/i.exec(req.get('authorization') || '');
  if (!m || m[1].trim() !== APP_KEY) return res.status(401).json({ ok: false, error: 'Neispravan pristupni ključ aplikacije.' });
  if (!LI_TOKEN) return res.status(500).json({ ok: false, error: 'LinkedIn token nije postavljen na serveru.' });
  next();
});

const li = (url, payload, method = 'POST') =>
  fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${LI_TOKEN}`,
      'Content-Type': 'application/json',
      'X-Restli-Protocol-Version': '2.0.0',
      'LinkedIn-Version': LI_VERSION
    },
    body: JSON.stringify(payload)
  });

async function uploadImage(author, dataUrl) {
  const m = /^data:image\/[a-z.+-]+;base64,(.+)$/i.exec(dataUrl || '');
  if (!m) return null;
  const bytes = Buffer.from(m[1], 'base64');
  if (!bytes.length) return null;

  const init = await li('https://api.linkedin.com/rest/images?action=initializeUpload', {
    initializeUploadRequest: { owner: author }
  });
  if (!init.ok) return null;
  const { value } = await init.json();
  if (!value || !value.uploadUrl) return null;

  const put = await fetch(value.uploadUrl, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${LI_TOKEN}`, 'Content-Type': 'application/octet-stream' },
    body: bytes
  });
  return put.ok ? value.image : null;
}

app.post('/api/linkedin', async (req, res) => {
  try {
    const { text = '', url = '', image = '' } = req.body || {};
    const author = (req.body && req.body.author) || LI_AUTHOR;
    const body = String(text).trim() || String(url).trim();

    if (!body) return res.status(422).json({ ok: false, error: 'Nema teksta ni poveznice.' });
    if (!author.startsWith('urn:li:')) return res.status(422).json({ ok: false, error: 'Nedostaje ispravan autor URN.' });

    const imageUrn = image ? await uploadImage(author, image) : null;
    const commentary = url && !body.includes(url) ? `${body}\n\n${url}` : body;

    const post = {
      author,
      commentary,
      visibility: 'PUBLIC',
      distribution: { feedDistribution: 'MAIN_FEED', targetEntities: [], thirdPartyDistributionChannels: [] },
      lifecycleState: 'PUBLISHED',
      isReshareDisabledByAuthor: false
    };
    if (imageUrn) post.content = { media: { id: imageUrn, title: body.slice(0, 200) } };
    else if (url) post.content = { article: { source: url, title: body.slice(0, 200) } };

    const r = await li('https://api.linkedin.com/rest/posts', post);
    const detail = await r.json().catch(() => ({}));

    if (!r.ok) return res.status(r.status).json({ ok: false, error: 'LinkedIn je odbio objavu.', detail });
    res.json({ ok: true, id: r.headers.get('x-restli-id') || detail.id || null });
  } catch (e) {
    res.status(502).json({ ok: false, error: String(e && e.message ? e.message : e) });
  }
});

app.listen(PORT, () => console.log(`LinkedIn relay na :${PORT}/api/linkedin`));
