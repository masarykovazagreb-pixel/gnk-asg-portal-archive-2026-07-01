# LinkedIn relay — postavljanje (10 minuta)

Aplikacija ne može objavljivati direktno na LinkedIn (LinkedIn blokira pozive iz preglednika i token
ne smije biti javan). Relay je mali posrednik na vašem serveru: aplikacija zove njega, on zove LinkedIn.

Izaberite jednu datoteku, prema tome na čemu je portal:

- **PHP** (Apache/cPanel, WordPress hosting) → `linkedin-relay.php`
  Postavite kao `https://www.gnk-asg.hr/api/linkedin/index.php`
- **Node** → `linkedin-relay.js` (`npm i express`, pa `node linkedin-relay.js`)

## 1. LinkedIn strana (jednom)
1. developer.linkedin.com → *Create app*, povežite s vašom LinkedIn Page.
2. Products: **Share on LinkedIn** (osobni profil) i/ili **Community Management API** (objava kao stranica).
3. Napravite OAuth token s opsegom `w_member_social` (profil) ili `w_organization_social` (stranica).
4. Zapišite autor URN: `urn:li:person:XXXX` ili `urn:li:organization:12345`.

## 2. Server strana
Postavite tri vrijednosti kao varijable okoline (ili ih upišite na početku datoteke):

    GNK_APP_KEY      = dugačak slučajan niz — ovo upisujete u aplikaciju
    LINKEDIN_TOKEN   = LinkedIn access token (ostaje samo na serveru)
    LINKEDIN_AUTHOR  = urn:li:person:XXXX  ili  urn:li:organization:12345

## 3. Aplikacija
Više → **LinkedIn**:
- adresa relaya: `https://www.gnk-asg.hr/api/linkedin`
- pristupni ključ: `GNK_APP_KEY` (ne LinkedIn token!)
- autor URN: isti kao na serveru (može ostati prazno ako je postavljen na serveru)

Pritisnite **Testiraj vezu** — ako piše da je LinkedIn prihvatio objavu, gotovo je: svi LinkedIn gumbi
u aplikaciji od tada objavljuju direktno, a u Objavi prekidač „Objavi i na LinkedIn" objavljuje na
portal i LinkedIn u jednom koraku.

## Protokol (za vašeg programera)

    POST /api/linkedin
    Authorization: Bearer <GNK_APP_KEY>
    { "author": "urn:li:person:…", "text": "…", "url": "https://…", "image": "data:image/jpeg;base64,…" }

    200 → { "ok": true, "id": "urn:li:share:…" }
    4xx/5xx → { "ok": false, "error": "…", "detail": … }

Slika je opcionalna; relay je registrira kroz LinkedIn Images API i priloži objavi. Bez slike, a s
poveznicom, objava ide kao article share. LinkedIn tokeni istječu (~60 dana) — obnovite ga na serveru;
u aplikaciji se ništa ne mijenja.
