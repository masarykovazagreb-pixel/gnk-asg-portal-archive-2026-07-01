<?php
/**
 * GNK ASG — poruke tima (/api/messages)
 * Postaviti kao: https://www.gnk-asg.hr/api/messages  (npr. /api/messages/index.php)
 *
 * Aplikacija (Više → Poruke tima → Server tima) koristi:
 *
 *   GET  /api/messages?limit=100[&since=<ms>]        → { ok, items: [{ id, author, text, at }] }
 *   POST /api/messages   { author, text }           → { ok, item }        (Bearer token)
 *   DELETE /api/messages?id=<id>                    → { ok }             (Bearer token)
 *
 * Token je isti onaj koji aplikacija dobije prijavom na /api/objave/login,
 * pa se koristi ista provjera (HMAC potpis + rok).
 *
 * Poruke se čuvaju u jednoj JSONL datoteci — bez baze, s zaključavanjem pri pisanju.
 */

declare(strict_types=1);

/* ─── Konfiguracija ────────────────────────────────────────────────────── */

$DATA_FILE    = __DIR__ . '/_data/messages.jsonl';   // najbolje van web korijena
$ALLOW_ORIGIN = 'https://www.gnk-asg.hr';
$TOKEN_SECRET = getenv('GNK_TOKEN_SECRET') ?: 'promijeni-me-dugacki-slucajni-niz'; // ISTI kao u objave-api.php
$MAX_KEEP     = 500;                                  // koliko zadnjih poruka čuvamo
$MAX_LEN      = 2000;                                  // najveća duljina poruke
$READ_PUBLIC  = false;                                 // true = čitanje bez tokena

/* ─── Zajedničko ───────────────────────────────────────────────────────── */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . $ALLOW_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Cache-Control: no-store');
header('Vary: Origin');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }

@mkdir(dirname($DATA_FILE), 0775, true);

$auth  = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = preg_match('/^Bearer\s+(.+)$/i', $auth, $m) ? trim($m[1]) : '';
$user  = tokenUser($token, $TOKEN_SECRET);           // null ako token ne vrijedi

/* ─── GET — popis poruka ───────────────────────────────────────────────── */

if ($method === 'GET') {
    if (!$READ_PUBLIC && $user === null) fail(401, 'Prijava je istekla ili nije valjana.');

    $limit = max(1, min(300, (int)($_GET['limit'] ?? 100)));
    $since = (float)($_GET['since'] ?? 0);

    $items = readAll($DATA_FILE);
    if ($since > 0) {
        $items = array_values(array_filter($items, fn($x) => (float)($x['at'] ?? 0) > $since));
    }
    // najnovije prvo (aplikacija tako prikazuje nit)
    usort($items, fn($a, $b) => ($b['at'] ?? 0) <=> ($a['at'] ?? 0));

    echo json_encode(['ok' => true, 'items' => array_slice($items, 0, $limit), 'now' => round(microtime(true) * 1000)],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ─── POST — nova poruka ───────────────────────────────────────────────── */

if ($method === 'POST') {
    if ($user === null) fail(401, 'Za objavu poruke potrebna je prijava.');

    $in     = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];
    $text   = trim((string)($in['text'] ?? ''));
    $author = trim((string)($in['author'] ?? '')) ?: $user;

    if ($text === '')                 fail(422, 'Poruka je prazna.');
    if (mb_strlen($text) > $MAX_LEN)  fail(422, 'Poruka je predugačka.');
    if (mb_strlen($author) > 60)      $author = mb_substr($author, 0, 60);

    // Jednostavna zaštita od dvostrukog slanja: ista poruka istog autora u 10 s.
    $recent = array_slice(readAll($DATA_FILE), -20);
    foreach ($recent as $r) {
        if (($r['text'] ?? '') === $text && ($r['author'] ?? '') === $author
            && (microtime(true) * 1000 - (float)($r['at'] ?? 0)) < 10000) {
            echo json_encode(['ok' => true, 'item' => $r, 'duplicate' => true], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    $item = [
        'id'     => bin2hex(random_bytes(8)),
        'author' => $author,
        'text'   => $text,
        'at'     => round(microtime(true) * 1000),
        'user'   => $user,
        'ip'     => hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '')),  // samo hash, radi zloupotreba
    ];

    append($DATA_FILE, $item, $MAX_KEEP);

    echo json_encode(['ok' => true, 'item' => $item], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ─── DELETE — brisanje poruke ─────────────────────────────────────────── */

if ($method === 'DELETE') {
    if ($user === null) fail(401, 'Za brisanje je potrebna prijava.');
    $id = preg_replace('/[^a-f0-9]/', '', (string)($_GET['id'] ?? ''));
    if ($id === '') fail(422, 'Nedostaje id.');

    $items = readAll($DATA_FILE);
    $left  = array_values(array_filter($items, fn($x) => ($x['id'] ?? '') !== $id));
    if (count($left) === count($items)) fail(404, 'Poruka ne postoji.');
    writeAll($DATA_FILE, $left);

    echo json_encode(['ok' => true]);
    exit;
}

fail(405, 'Only GET, POST, DELETE');

/* ─── Pomoćne funkcije ─────────────────────────────────────────────────── */

function readAll(string $file): array {
    if (!is_file($file)) return [];
    $out = [];
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $d = json_decode($line, true);
        if (is_array($d)) $out[] = $d;
    }
    return $out;
}

function append(string $file, array $item, int $maxKeep): void {
    $fh = fopen($file, 'c+');
    if (!$fh) fail(500, 'Ne mogu pisati u datoteku poruka.');
    flock($fh, LOCK_EX);
    fseek($fh, 0, SEEK_END);
    fwrite($fh, json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    flock($fh, LOCK_UN);
    fclose($fh);

    // Podreži datoteku ako je narasla.
    $items = readAll($file);
    if (count($items) > $maxKeep) writeAll($file, array_slice($items, -$maxKeep));
}

function writeAll(string $file, array $items): void {
    $tmp = $file . '.tmp';
    $fh = fopen($tmp, 'w');
    if (!$fh) fail(500, 'Ne mogu zapisati poruke.');
    foreach ($items as $i) {
        fwrite($fh, json_encode($i, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
    }
    fclose($fh);
    rename($tmp, $file);
}

/** Vraća korisnika iz tokena (isti format kao objave-api.php) ili null. */
function tokenUser(string $t, string $secret): ?string {
    if ($t === '') return null;
    $parts = explode('.', $t);
    if (count($parts) !== 2) return null;
    [$p, $sig] = $parts;
    if (!hash_equals(hash_hmac('sha256', $p, $secret), $sig)) return null;
    $d = json_decode((string)base64_decode($p), true);
    if (!is_array($d) || ($d['e'] ?? 0) <= time()) return null;
    return (string)($d['u'] ?? 'admin');
}

function fail(int $code, string $msg): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}
