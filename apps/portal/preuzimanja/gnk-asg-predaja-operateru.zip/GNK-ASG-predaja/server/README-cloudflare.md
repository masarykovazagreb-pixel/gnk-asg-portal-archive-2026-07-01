# API ugovor za Cloudflare Worker (gnk-asg-app-api)

Portal `gnk-asg.hr` radi na Cloudflare Workerima — PHP se ne izvršava.
PHP datoteke u ovoj mapi ostaju samo kao opcija A (zaseban obični hosting).
Za opciju B (Worker) worker mora odgovarati **točno ovom protokolu**, jer ga aplikacija tako zove.

Sve odgovore aplikacija čita kao JSON. Zaglavlja koja worker mora vraćati na svaku rutu:

```
Access-Control-Allow-Origin: https://gnk-asg.hr        (i https://www.gnk-asg.hr)
Access-Control-Allow-Headers: Content-Type, Authorization
Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS
```

`OPTIONS` → `204` bez tijela.

---

## 1. `POST /api/objave/login`

Prijava istim administratorskim podatcima kao web stranica.

```json
{ "user": "admin", "password": "..." }
```

Odgovor `200`:

```json
{ "ok": true, "token": "<hmac-token>", "user": "admin" }
```

Neispravno → `401` `{ "ok": false, "error": "..." }`
Aplikacija sprema `token` i šalje ga dalje kao `Authorization: Bearer <token>`.
Provjera lozinke: `GNK_ADMIN_HASH` = SHA-256 lozinke u hex zapisu.

---

## 2. `POST /api/objave` — objava (Bearer token)

```json
{
  "category": "objave" | "komentari",
  "title": "Naslov",
  "body": "Tekst objave",
  "image": "data:image/jpeg;base64,..."   // opcionalno
}
```

Odgovor `200`:

```json
{ "ok": true, "id": "20260729-...", "url": "https://gnk-asg.hr/objave/naslov/", "image": "/assets/objave/..." }
```

`url` nije obvezan, ali ako ga vrati, aplikacija ga koristi za LinkedIn dijeljenje.
Ako worker ne može zapisati stranicu, dovoljno je spremiti zapis u KV i vratiti `url` rubrike.

---

## 3. `GET /api/objave?limit=40[&category=objave]` — popis (javno ili s tokenom)

```json
{ "ok": true, "items": [
  { "id": "...", "category": "objave", "title": "...", "url": "https://...", "image": "https://...", "at": 1785000000000 }
] }
```

Aplikacija prikazuje `title`, `image`, `url` i `category` na ekranima **Objave** i **Analize**
(`category: "analize"` ide u Analize). Ako ruta ne postoji, aplikacija se vraća na čitanje
javnih stranica portala kroz proxy — radi, ali sporije.

---

## 4. `GET /api/messages?limit=100[&since=<ms>]` — poruke tima (Bearer token)

```json
{ "ok": true, "items": [ { "id": "...", "author": "Nermin", "text": "...", "at": 1785000000000 } ], "now": 1785000000001 }
```

## 5. `POST /api/messages` (Bearer token)

```json
{ "author": "Nermin", "text": "..." }
```

→ `200` `{ "ok": true, "item": { "id": "...", "author": "...", "text": "...", "at": 1785... } }`

`DELETE /api/messages?id=<id>` → `{ "ok": true }` (opcionalno; aplikacija briše i lokalno).
Aplikacija osvježava nit svakih 15 s dok je ekran otvoren.

---

## 6. `POST /api/ai` — AI asistent (bez tokena, s ograničenjem po IP-u)

```json
{ "question": "...", "lang": "hr" | "en", "source": "app" }
```

→ `200` `{ "ok": true, "answer": "..." }` · `503` ako servis nije dostupan
(aplikacija tada odgovara iz vlastite baze javnih podataka — nema greške za korisnika).

Sistemski kontekst i pravila („samo javni podatci portala, bez izmišljanja, bez investicijskih
savjeta") su u `ai-api.php` i mogu se prepisati u worker jedan-na-jedan.

---

## 7. `POST /api/linkedin` — objava na LinkedIn (Bearer `GNK_APP_KEY`)

```json
{ "author": "urn:li:person:...", "text": "...", "url": "https://...", "image": "data:image/jpeg;base64,..." }
```

→ `200` `{ "ok": true, "id": "urn:li:share:..." }`
LinkedIn token ostaje u workeru (`LINKEDIN_TOKEN`), nikad u aplikaciji.
Logika (registracija slike + Posts API) je u `linkedin-relay.js` — spremna za prijenos u worker,
`fetch` je isti.

---

## 8. `GET /api/stats` — posjeti portalu (opcionalno)

Bilo koji JSON s brojevima; aplikacija prikazuje prvih 8 parova ključ/vrijednost:

```json
{ "ok": true, "posjeta_danas": 412, "posjeta_mjesec": 9134, "instalacija_app": 27 }
```

---

## 9. Provjera nakon objave

`GET /api/app-health` → `{ "ok": true }` (aplikacija ga ne traži, ali služi za brzu provjeru ruta).

**Rute u Cloudflare nadzornoj ploči** moraju pokazivati na worker:
`gnk-asg.hr/api/objave*`, `gnk-asg.hr/api/messages*`, `gnk-asg.hr/api/ai`,
`gnk-asg.hr/api/linkedin`, `gnk-asg.hr/api/stats`, `gnk-asg.hr/api/app-health`
— i ne smiju se preklapati s rutama glavnog workera.

---

## 10. Gdje se adrese upisuju u aplikaciji

Ništa se ne mijenja u kodu aplikacije — adrese se upisuju u sučelju i pamte na uređaju:

| Ekran | Polje | Vrijednost |
| --- | --- | --- |
| Objavi | Server za objavu | `https://gnk-asg.hr/api/objave` |
| Više → LinkedIn | adresa relaya + pristupni ključ | `https://gnk-asg.hr/api/linkedin` + `GNK_APP_KEY` |
| AI asistent | Poveži s portalom | `https://gnk-asg.hr/api/ai` |
| Poruke tima | Server tima | `https://gnk-asg.hr/api/messages` |
| Statistika | Posjeti portalu | `https://gnk-asg.hr/api/stats` |

Bez ijednog od tih endpointa aplikacija radi u cijelosti — objave, poruke, troškovi, potpisi i
sastanci ostaju spremljeni na uređaju i označeni „čeka sinkronizaciju".
