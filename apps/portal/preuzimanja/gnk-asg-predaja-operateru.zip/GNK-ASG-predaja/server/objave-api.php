<?php
/**
 * GNK ASG — API za objave i komentare
 * Postaviti kao: https://www.gnk-asg.hr/api/objave  (npr. /api/objave/index.php)
 *
 * Aplikacija (GNK ASG PWA, ekran „Objavi") koristi:
 *
 *   POST /api/objave/login     { user, password }                  → { ok, token }
 *   POST /api/objave           { category, title, body, image }    → { ok, id, url }   (Bearer token)
 *   GET  /api/objave?limit=40&category=objave                      → { ok, items: [...] }
 *   DELETE /api/objave?id=...                                      → { ok }            (Bearer token)
 *
 * Objave se pišu kao JSON zapisi + slika na disk, i (opcionalno) kao statična HTML stranica
 * u /objave/<slug>/ odnosno /komentari/<slug>/ da su odmah vidljive na portalu.
 */

declare(strict_types=1);

/* ─── Konfiguracija ────────────────────────────────────────────────────── */

$SITE         = 'https://www.gnk-asg.hr';
$DATA_DIR     = __DIR__ . '/_data';                 // JSON zapisi (van web korijena je bolje ako možete)
$MEDIA_DIR    = dirname(__DIR__) . '/assets/objave';// slike (dostupno kao /assets/objave/...)
$MEDIA_URL    = '/assets/objave';
$PAGES_ROOT   = dirname(__DIR__);                   // korijen portala za generirane stranice
$WRITE_PAGES  = true;                               // false ako objave prikazujete iz JSON-a
$ALLOW_ORIGIN = $SITE;

// Administrator — iste vjerodajnice kao na web stranici.
// Napravite hash jednom:  php -r 'echo password_hash("vasa-lozinka", PASSWORD_DEFAULT);'
$ADMIN_USER   = getenv('GNK_ADMIN_USER') ?: 'admin';
$ADMIN_HASH   = getenv('GNK_ADMIN_HASH') ?: '';     // npr. $2y$10$...
$TOKEN_SECRET = getenv('GNK_TOKEN_SECRET') ?: 'promijeni-me-dugacki-slucajni-niz';
$TOKEN_TTL    = 60 * 60 * 24 * 30;                  // 30 dana

$CATS = ['objave' => '/objave', 'komentari' => '/komentari'];

/* ─── Zajedničko ───────────────────────────────────────────────────────── */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . $ALLOW_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Vary: Origin');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }

@mkdir($DATA_DIR, 0775, true);
@mkdir($MEDIA_DIR, 0775, true);

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '', '/');
$isLogin = substr($path, -6) === '/login';
$in = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];

/* ─── 1. Prijava ───────────────────────────────────────────────────────── */

if ($isLogin) {
    if ($method !== 'POST') fail(405, 'Only POST');
    $user = trim((string)($in['user'] ?? ''));
    $pass = (string)($in['password'] ?? '');

    $ok = $ADMIN_HASH !== ''
        ? (hash_equals($ADMIN_USER, $user) && password_verify($pass, $ADMIN_HASH))
        : false;

    if (!$ok) { usleep(400000); fail(401, 'Neispravni podatci za prijavu.'); }

    echo json_encode(['ok' => true, 'token' => makeToken($user, $TOKEN_SECRET, $TOKEN_TTL), 'user' => $user]);
    exit;
}

/* ─── 2. Popis objava (javno) ──────────────────────────────────────────── */

if ($method === 'GET') {
    $limit = max(1, min(100, (int)($_GET['limit'] ?? 40)));
    $cat   = $_GET['category'] ?? '';
    $items = [];

    foreach (glob($DATA_DIR . '/*.json') ?: [] as $f) {
        $rec = json_decode((string)file_get_contents($f), true);
        if (!is_array($rec)) continue;
        if ($cat !== '' && ($rec['category'] ?? '') !== $cat) continue;
        unset($rec['image']);                        // popis ne nosi base64
        $items[] = $rec;
    }
    usort($items, fn($a, $b) => ($b['at'] ?? 0) <=> ($a['at'] ?? 0));

    echo json_encode(['ok' => true, 'items' => array_slice($items, 0, $limit)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ─── 3. Objava i brisanje (traže token) ───────────────────────────────── */

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m) || !checkToken(trim($m[1]), $TOKEN_SECRET)) {
    fail(401, 'Prijava je istekla ili nije valjana.');
}

if ($method === 'DELETE') {
    $id = preg_replace('/[^a-z0-9\-]/i', '', (string)($_GET['id'] ?? ''));
    if ($id === '' || !is_file("$DATA_DIR/$id.json")) fail(404, 'Objava ne postoji.');
    $rec = json_decode((string)file_get_contents("$DATA_DIR/$id.json"), true) ?: [];
    @unlink("$DATA_DIR/$id.json");
    if (!empty($rec['imageFile'])) @unlink($MEDIA_DIR . '/' . basename($rec['imageFile']));
    if (!empty($rec['pageDir']) && is_dir($rec['pageDir'])) { @unlink($rec['pageDir'] . '/index.html'); @rmdir($rec['pageDir']); }
    echo json_encode(['ok' => true]);
    exit;
}

if ($method !== 'POST') fail(405, 'Only GET, POST, DELETE');

$cat   = (string)($in['category'] ?? 'objave');
$title = trim((string)($in['title'] ?? ''));
$body  = trim((string)($in['body'] ?? ''));
$image = (string)($in['image'] ?? '');

if (!isset($CATS[$cat])) fail(422, 'Nepoznata rubrika.');
if ($title === '' && $body === '') fail(422, 'Nema naslova ni teksta.');
if ($title === '') $title = mb_substr($body, 0, 70);
if (mb_strlen($title) > 200) $title = mb_substr($title, 0, 200);

$at   = time();
$slug = slugify($title) ?: ('objava-' . $at);
$id   = date('Ymd-His', $at) . '-' . $slug;

/* slika */
$imageFile = null; $imageUrl = null;
if ($image !== '' && preg_match('#^data:image/([a-z]+);base64,#i', $image, $mm)) {
    $ext   = strtolower($mm[1]) === 'png' ? 'png' : 'jpg';
    $bytes = base64_decode(preg_replace('#^data:image/[a-z]+;base64,#i', '', $image), true);
    if ($bytes !== false && strlen($bytes) <= 8 * 1024 * 1024) {
        $imageFile = "$id.$ext";
        file_put_contents("$MEDIA_DIR/$imageFile", $bytes);
        $imageUrl = "$MEDIA_URL/$imageFile";
    }
}

$pageDir = null; $url = $SITE . $CATS[$cat] . '/';
if ($WRITE_PAGES) {
    $pageDir = $PAGES_ROOT . $CATS[$cat] . '/' . $slug;
    @mkdir($pageDir, 0775, true);
    file_put_contents($pageDir . '/index.html', renderPage($title, $body, $imageUrl, $at, $cat, $SITE));
    $url = $SITE . $CATS[$cat] . '/' . $slug . '/';
}

$rec = [
    'id' => $id, 'category' => $cat, 'title' => $title, 'body' => $body,
    'image' => $imageUrl, 'imageFile' => $imageFile, 'at' => $at * 1000,
    'date' => date('c', $at), 'url' => $url, 'pageDir' => $pageDir, 'source' => 'app'
];
file_put_contents("$DATA_DIR/$id.json", json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

echo json_encode(['ok' => true, 'id' => $id, 'url' => $url, 'image' => $imageUrl], JSON_UNESCAPED_SLASHES);
exit;

/* ─── Pomoćne funkcije ─────────────────────────────────────────────────── */

function makeToken(string $user, string $secret, int $ttl): string {
    $p = base64_encode(json_encode(['u' => $user, 'e' => time() + $ttl]));
    return $p . '.' . hash_hmac('sha256', $p, $secret);
}
function checkToken(string $t, string $secret): bool {
    $parts = explode('.', $t);
    if (count($parts) !== 2) return false;
    [$p, $sig] = $parts;
    if (!hash_equals(hash_hmac('sha256', $p, $secret), $sig)) return false;
    $d = json_decode((string)base64_decode($p), true);
    return is_array($d) && ($d['e'] ?? 0) > time();
}
function slugify(string $s): string {
    $s = strtr($s, ['č'=>'c','ć'=>'c','ž'=>'z','š'=>'s','đ'=>'d','Č'=>'c','Ć'=>'c','Ž'=>'z','Š'=>'s','Đ'=>'d']);
    $s = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $s) ?: '');
    return trim(substr($s, 0, 70), '-');
}
function renderPage(string $title, string $body, ?string $img, int $at, string $cat, string $site): string {
    $h = fn($x) => htmlspecialchars($x, ENT_QUOTES, 'UTF-8');
    $paras = '';
    foreach (preg_split('/\n{2,}/', $body) as $p) {
        $p = trim($p); if ($p !== '') $paras .= '<p>' . nl2br($h($p)) . '</p>' . "\n";
    }
    $imgTag = $img ? '<figure><img src="' . $h($img) . '" alt="' . $h($title) . '"></figure>' : '';
    $kick   = $cat === 'objave' ? 'Objave' : 'Komentari';
    return '<!DOCTYPE html>
<html lang="hr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>' . $h($title) . ' | GNK ASG d.o.o.</title>
<meta name="description" content="' . $h(mb_substr(strip_tags($body), 0, 160)) . '">
<meta property="og:type" content="article">
<meta property="og:title" content="' . $h($title) . '">
<meta property="og:description" content="' . $h(mb_substr(strip_tags($body), 0, 200)) . '">
' . ($img ? '<meta property="og:image" content="' . $h($site . $img) . '">' : '') . '
<link rel="stylesheet" href="/assets/styles.css">
</head><body>
<article>
<p class="kicker">' . $h($kick) . ' · ' . date('d.m.Y.', $at) . '</p>
<h1>' . $h($title) . '</h1>
' . $imgTag . '
' . $paras . '
<p class="meta">GNK ASG d.o.o. · Nermin Sefić</p>
</article>
</body></html>';
}
function fail(int $code, string $msg): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}
