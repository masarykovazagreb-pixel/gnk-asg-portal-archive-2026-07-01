<?php
/**
 * GNK ASG — LinkedIn relay
 * Postaviti kao: https://www.gnk-asg.hr/api/linkedin  (npr. /api/linkedin/index.php)
 *
 * Aplikacija (GNK ASG PWA) šalje:
 *   POST  Content-Type: application/json
 *         Authorization: Bearer <APP_KEY>
 *         { "author": "urn:li:person:...", "text": "...", "url": "https://...", "image": "data:image/jpeg;base64,..." }
 *
 * Relay objavljuje na LinkedIn i vraća { ok: true, id: "urn:li:share:..." }.
 * LinkedIn access token OSTAJE NA SERVERU — nikad u aplikaciji.
 */

declare(strict_types=1);

/* ─── 1. Konfiguracija ─────────────────────────────────────────────────── */

$APP_KEY      = getenv('GNK_APP_KEY')      ?: 'promijeni-me-dugacki-slucajni-niz';
$LI_TOKEN     = getenv('LINKEDIN_TOKEN')   ?: '';           // LinkedIn access token (w_member_social ili w_organization_social)
$LI_AUTHOR    = getenv('LINKEDIN_AUTHOR')  ?: '';           // npr. urn:li:person:XXXX ili urn:li:organization:12345
$ALLOW_ORIGIN = 'https://www.gnk-asg.hr';                   // aplikacija je na istoj domeni (/app/)
$LI_VERSION   = '202405';                                   // LinkedIn-Version

/* ─── 2. CORS i metoda ─────────────────────────────────────────────────── */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . $ALLOW_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Vary: Origin');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { fail(405, 'Only POST'); }

/* ─── 3. Provjera ključa aplikacije ────────────────────────────────────── */

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (!preg_match('/^Bearer\s+(.+)$/i', $auth, $m) || !hash_equals($APP_KEY, trim($m[1]))) {
    fail(401, 'Neispravan pristupni ključ aplikacije.');
}
if ($LI_TOKEN === '') { fail(500, 'LinkedIn token nije postavljen na serveru.'); }

/* ─── 4. Ulazni podatci ────────────────────────────────────────────────── */

$in     = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];
$text   = trim((string)($in['text']  ?? ''));
$link   = trim((string)($in['url']   ?? ''));
$image  = (string)($in['image'] ?? '');                     // data:image/...;base64,....
$author = trim((string)($in['author'] ?? '')) ?: $LI_AUTHOR;

if ($text === '' && $link === '') { fail(422, 'Nema teksta ni poveznice.'); }
if ($author === '' || strpos($author, 'urn:li:') !== 0) { fail(422, 'Nedostaje ispravan autor URN.'); }
if ($text === '') { $text = $link; }

/* ─── 5. Ako ima fotografije: registriraj i pošalji binarno ────────────── */

$imageUrn = null;
if ($image !== '' && preg_match('#^data:image/[a-z.+-]+;base64,#i', $image)) {
    $bytes = base64_decode(preg_replace('#^data:image/[a-z.+-]+;base64,#i', '', $image), true);
    if ($bytes !== false && strlen($bytes) > 0) {
        [$code, $reg] = li('POST', 'https://api.linkedin.com/rest/images?action=initializeUpload', [
            'initializeUploadRequest' => ['owner' => $author]
        ], $LI_TOKEN, $LI_VERSION);

        if ($code >= 200 && $code < 300 && !empty($reg['value']['uploadUrl'])) {
            $up = curl_init($reg['value']['uploadUrl']);
            curl_setopt_array($up, [
                CURLOPT_CUSTOMREQUEST  => 'PUT',
                CURLOPT_POSTFIELDS     => $bytes,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $LI_TOKEN, 'Content-Type: application/octet-stream'],
                CURLOPT_TIMEOUT        => 60,
            ]);
            curl_exec($up);
            $upCode = (int)curl_getinfo($up, CURLINFO_HTTP_CODE);
            curl_close($up);
            if ($upCode >= 200 && $upCode < 300) { $imageUrn = $reg['value']['image'] ?? null; }
        }
    }
}

/* ─── 6. Objava (Posts API) ────────────────────────────────────────────── */

$commentary = $text . ($link !== '' && strpos($text, $link) === false ? "\n\n" . $link : '');

$post = [
    'author'                    => $author,
    'commentary'                => $commentary,
    'visibility'                => 'PUBLIC',
    'distribution'              => ['feedDistribution' => 'MAIN_FEED', 'targetEntities' => [], 'thirdPartyDistributionChannels' => []],
    'lifecycleState'            => 'PUBLISHED',
    'isReshareDisabledByAuthor' => false,
];

if ($imageUrn) {
    $post['content'] = ['media' => ['id' => $imageUrn, 'title' => mb_substr($text, 0, 200)]];
} elseif ($link !== '') {
    $post['content'] = ['article' => ['source' => $link, 'title' => mb_substr($text, 0, 200)]];
}

[$code, $body, $headers] = li('POST', 'https://api.linkedin.com/rest/posts', $post, $LI_TOKEN, $LI_VERSION, true);

if ($code >= 200 && $code < 300) {
    echo json_encode(['ok' => true, 'id' => $headers['x-restli-id'] ?? ($body['id'] ?? null)]);
    exit;
}

fail($code >= 400 ? $code : 502, 'LinkedIn je odbio objavu.', $body);

/* ─── Pomoćne funkcije ─────────────────────────────────────────────────── */

function li(string $method, string $url, array $payload, string $token, string $version, bool $wantHeaders = false): array {
    $ch = curl_init($url);
    $raw = '';
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'X-Restli-Protocol-Version: 2.0.0',
            'LinkedIn-Version: ' . $version,
        ],
        CURLOPT_HEADERFUNCTION => function ($ch2, $line) use (&$raw) { $raw .= $line; return strlen($line); },
    ]);
    $res  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $hdr = [];
    foreach (explode("\r\n", $raw) as $l) {
        if (strpos($l, ':') !== false) { [$k, $v] = explode(':', $l, 2); $hdr[strtolower(trim($k))] = trim($v); }
    }
    $json = json_decode((string)$res, true);
    return $wantHeaders ? [$code, is_array($json) ? $json : [], $hdr] : [$code, is_array($json) ? $json : []];
}

function fail(int $code, string $msg, $detail = null): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg, 'detail' => $detail], JSON_UNESCAPED_UNICODE);
    exit;
}
