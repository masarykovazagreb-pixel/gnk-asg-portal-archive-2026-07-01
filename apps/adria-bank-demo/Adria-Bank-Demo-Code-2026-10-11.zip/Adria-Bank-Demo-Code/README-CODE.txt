Adria Bank Demo — code bundle

This ZIP contains the synthetic demo source, tests, local web server, package manifests, and product/research documentation. It does not include the Windows launcher scripts.

Requirements: Node.js 22.12+ and npm. From this extracted folder run:
  npm ci
  npm test
  npm run dev
Then open http://localhost:4173/ .

For the Windows desktop launcher bundle, use Adria-Bank-Demo-Desktop-2026-10-11.zip. The desktop bundle is a source ZIP, not a standalone EXE; its first-run installation downloads dependencies and the Electron runtime with TLS verification enabled.

DEMO DESKTOP ADRIA BANK — synthetic local training data only. No real account, payment, trade, onboarding, or external authorization is available.
